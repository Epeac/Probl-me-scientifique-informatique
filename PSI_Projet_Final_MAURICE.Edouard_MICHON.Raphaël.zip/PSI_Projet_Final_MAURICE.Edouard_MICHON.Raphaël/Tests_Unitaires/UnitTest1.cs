﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using System.Drawing;

namespace ImageViewerPSI

{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestFormImagetoFile()
        {
            MyImage Test = new MyImage("./ImagesLecture/grille.bmp");
            Test.FromImagetoFile("testons.bmp");
            byte[] attendu = File.ReadAllBytes("./ImagesLecture/grille.bmp");
            byte[] résultat = File.ReadAllBytes("testons.bmp");
            Assert.AreEqual(attendu.Length, résultat.Length);
            for(int i =0; i < attendu.Length;i++)
            {
                Assert.AreEqual(attendu[i], résultat[i]);
            }
        }
        [TestMethod]
        public void TestNoirEtBlanc()
        {
            MyImage Test = new MyImage("./ImagesLecture/coco.bmp");
            Program.NoirEtBlanc(Test);
            
            Bitmap Verif = new Bitmap("./ImagesLecture/coco.bmp");
            for(int i =0; i<Verif.Height; i++)
            {
                for(int j=0; j < Verif.Width; j++)
                {
                    Color mycolor = Verif.GetPixel(j, i);
                    int calcule = (mycolor.R + mycolor.G + mycolor.B) / 3;
                    Verif.SetPixel(j, i, Color.FromArgb(calcule, calcule, calcule));
                }
            }

            for (int i = 0; i < Verif.Height; i++)
            {
                for (int j = 0; j < Verif.Width; j++)
                {
                    Color attendu = Verif.GetPixel(j, Verif.Height-1-i);
                    Pixel resultat = Test.Im[i, j];
                    Assert.AreEqual(attendu.R, resultat.R);
                    Assert.AreEqual(attendu.G, resultat.G);
                    Assert.AreEqual(attendu.B, resultat.B);
                }
            }
        }
        [TestMethod]
        public void TestQRCode()
        {
            string resultat = Program.Correction(Program.Encode("HELLO WORLD"),19);
            string attendu = "0010000001011011000010110111100011010001011100101101110001001101010000110100000011101100000" +
                "1000111101100000100011110110000010001111011000001000111101100";
            Assert.AreEqual(attendu, resultat);

            Pixel[,] Test = Program.QRcode(19);
            Pixel noir = new Pixel(0, 0, 0);
            Pixel blanc = new Pixel(255, 255, 255);
            
            Assert.AreEqual(noir.R, Test[3, 3].R);
            Assert.AreEqual(noir.G, Test[3, 3].G);
            Assert.AreEqual(noir.B, Test[3, 3].B);
            Assert.AreEqual(blanc.R, Test[1, 1].R);
            Assert.AreEqual(blanc.G, Test[1, 1].G);
            Assert.AreEqual(blanc.B, Test[1, 1].B);

            Assert.AreEqual(noir.R, Test[17, 3].R);
            Assert.AreEqual(noir.G, Test[17, 3].G);
            Assert.AreEqual(noir.B, Test[17, 3].B);
            Assert.AreEqual(blanc.R, Test[19, 1].R);
            Assert.AreEqual(blanc.G, Test[19, 1].G);
            Assert.AreEqual(blanc.B, Test[19, 1].B);

            Assert.AreEqual(noir.R, Test[17, 17].R);
            Assert.AreEqual(noir.G, Test[17, 17].G);
            Assert.AreEqual(noir.B, Test[17, 17].B);
            Assert.AreEqual(blanc.R, Test[19, 19].R);
            Assert.AreEqual(blanc.G, Test[19, 19].G);
            Assert.AreEqual(blanc.B, Test[19, 19].B);

            Assert.AreEqual(noir.R, Test[7, 8].R);
            Assert.AreEqual(noir.G, Test[7, 8].G);
            Assert.AreEqual(noir.B, Test[7, 8].B);

            Test = Program.QRcode(34);
            Assert.AreEqual(noir.R, Test[6, 18].R);
            Assert.AreEqual(noir.G, Test[6, 18].G);
            Assert.AreEqual(noir.B, Test[6, 18].B);
            Assert.AreEqual(blanc.R, Test[7, 17].R);
            Assert.AreEqual(blanc.G, Test[7, 17].G);
            Assert.AreEqual(blanc.B, Test[7, 17].B);

            Test = Program.QRcode(55);
            Assert.AreEqual(noir.R, Test[6, 22].R);
            Assert.AreEqual(noir.G, Test[6, 22].G);
            Assert.AreEqual(noir.B, Test[6, 22].B);
            Assert.AreEqual(blanc.R, Test[7, 21].R);
            Assert.AreEqual(blanc.G, Test[7, 21].G);
            Assert.AreEqual(blanc.B, Test[7, 21].B);


        }

    }
}
