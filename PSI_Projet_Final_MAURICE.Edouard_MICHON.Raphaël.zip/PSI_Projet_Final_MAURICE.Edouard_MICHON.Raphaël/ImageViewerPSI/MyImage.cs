﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Drawing;
using System.Threading.Tasks;

namespace ImageViewerPSI
{
   public class MyImage
    {
        string typeImage;
        int tailleFichier;
        int tailleOffset;
        int largeur;
        int hauteur;
        int nbbitforcolor;
        int tailleImage;
        int tailleOriginale;
        Pixel[,] im;

        /// <summary>
        /// Créer une instance MyImage. Prend le nom du dossier. 
        /// Stocke les dimensions, la taille du Fichier et de l'Offset, le nombre de bits par couleur, tout les pixels et le type d'image. 
        /// De préférence BM
        /// </summary>
        /// <param name="myfile"></param>
        public MyImage(string myfile)
        {
            byte[] head = File.ReadAllBytes(myfile);
            typeImage = Convert.ToString(Convert.ToChar(head[0]));
            typeImage += Convert.ToString(Convert.ToChar(head[1]));

            byte[] tab = new byte[4] { head[2], head[3], head[4], head[5] };
            tailleFichier = Convertir_Endian_To_Int(tab);

            tab = new byte[4] { head[10], head[11], head[12], head[13] };
            tailleOffset = Convertir_Endian_To_Int(tab);

            tab = new byte[4] { head[18], head[19], head[20], head[21] };
            largeur = Convertir_Endian_To_Int(tab);
            tailleOriginale = largeur;

            tab = new byte[4] { head[22], head[23], head[24], head[25] };
            hauteur = Convertir_Endian_To_Int(tab);

            tab = new byte[2] { head[28], head[29] };
            nbbitforcolor = Convertir_Endian_To_Int(tab);

            tab = new byte[4] { head[34], head[35], head[36], head[37] };
            tailleImage = Convertir_Endian_To_Int(tab);

            im = new Pixel[hauteur, largeur];
            int n = 54;
            for (int i = 0; i < hauteur; i++)
            {
                for (int j = 0; j < largeur; j++)
                {
                    im[i, j] = new Pixel(head[n], head[n + 1], head[n + 2]);
                    n += 3;
                }
            }
        }
        /// <summary>
        /// Clone une instance MyImage.
        /// </summary>
        /// <param name="image"></param>
        public MyImage(MyImage image)
        {
            typeImage = image.TypeImage;

            tailleFichier = image.TailleFichier;

            tailleOffset = image.TailleOffset;

            largeur = image.Largeur;

            hauteur = image.Hauteur;

            nbbitforcolor = image.NbBitForColor;

            tailleImage = image.TailleImage;

            im = new Pixel[hauteur, largeur];
        }
        /// <summary>
        /// Prend un tableau de bytes en little Endian et le convertit en Int32. 
        /// </summary>
        /// <param name="tab"></param>
        /// <returns></returns>
        public int Convertir_Endian_To_Int(byte[] tab)
        {
            int rep = 0;
            for (int i = 0; i < tab.Length - 1; i++)
            {
                rep += Convert.ToInt32(tab[i] * Math.Pow(256, i));
            }
            return rep;
        }
        /// <summary>
        /// Prend un Int32 et le convertit en tableau de bytes en little Endian. 
        /// </summary>
        /// <param name="val"></param>
        /// <returns></returns>
        static byte[] Convertir_Int_To_Endian(int val)
        {
            byte[] rep = null;
            if (val >= 0)
            {
                rep = new byte[4];

                if (val < 256)
                {
                    rep[0] = Convert.ToByte(val);
                    rep[1] = 0;
                    rep[2] = 0;
                    rep[3] = 0;
                }
                else
                {
                    rep[3] = Convert.ToByte(val / (256 * 256 * 256));
                    if (val >= 256 * 256 * 256)
                    {
                        int j = val / (256 * 256 * 256);
                        val -= j * 256 * 256 * 256;
                    }
                    rep[2] = Convert.ToByte(val / (256 * 256));
                    if (val >= 256 * 256)
                    {
                        int j = val / (256 * 256);
                        val -= j * 256 * 256;
                    }
                    rep[1] = Convert.ToByte(val / 256);
                    if (val >= 256)
                    {
                        int j = val / (256);
                        val -= j * 256;
                    }
                    rep[0] = Convert.ToByte(val);

                }
            }
            return rep;
        }
        /// <summary>
        /// Créer un fichier avec l'instance MyImage et un nom de fichier. Prend le nom de fichier, puis écrit un à un les bytes du header,
        /// puis les pixels composant l'image. 
        /// </summary>
        /// <param name="file"></param>
        public void FromImagetoFile(string file)
        {
            BinaryWriter nouvfile = new BinaryWriter(File.Create(file));

            nouvfile.Write(Convert.ToByte(typeImage[0]));
            nouvfile.Write(Convert.ToByte(typeImage[1]));

            byte[] head = Convertir_Int_To_Endian(tailleFichier);
            for (int i = 0; i < head.Length; i++)
            {
                nouvfile.Write(head[i]);
            }
            nouvfile.Write(0);

            head = Convertir_Int_To_Endian(tailleOffset);
            for (int i = 0; i < head.Length; i++)
            {
                nouvfile.Write(head[i]);
            }


            head = Convertir_Int_To_Endian(40);
            for (int i = 0; i < head.Length; i++)
            {
                nouvfile.Write(head[i]);
            }

            head = Convertir_Int_To_Endian(largeur);
            for (int i = 0; i < head.Length; i++)
            {
                nouvfile.Write(head[i]);
            }

            head = Convertir_Int_To_Endian(hauteur);
            for (int i = 0; i < head.Length; i++)
            {
                nouvfile.Write(head[i]);
            }

            nouvfile.Write(true); nouvfile.Write(false);

            head = Convertir_Int_To_Endian(nbbitforcolor);
            for (int i = 0; i < 2; i++)
            {
                nouvfile.Write(head[i]);
            }
            nouvfile.Write(0);
            head = Convertir_Int_To_Endian(tailleImage);
            nouvfile.Write(head);
            for (int i = 0; i < 4; i++) { nouvfile.Write(0); }

            for (int i = 0; i < hauteur; i++)
            {
                for (int j = 0; j < largeur; j++)
                {
                    nouvfile.Write(im[i, j].R);
                    nouvfile.Write(im[i, j].G);
                    nouvfile.Write(im[i, j].B);

                }
            }

            nouvfile.Close();
        }
        /// <summary>
        /// Change les dimensions et l'espace mémoire de l'instance MyImage.
        /// Prend un Boolean pour changer l'espace mémoire de l'image originale ou non.
        /// </summary>
        /// <param name="ChangerTailleOriginale"></param>
        public void ChangerTailleImage(bool ChangerTailleOriginale = false)
        {
            tailleImage = Im.Length * 3;
            hauteur = Im.GetLength(0);
            largeur = Im.GetLength(1);
            if (ChangerTailleOriginale) { tailleOriginale = largeur; }
        }
        /// <summary>
        /// Retourne le type de l'image
        /// </summary>
        public string TypeImage
        {
            get { return typeImage; }
        }
        /// <summary>
        /// Retourne la taille du Fichier
        /// </summary>
        public int TailleFichier
        {
            get { return tailleFichier; }
        }
        /// <summary>
        /// Retourne la taille de l'Offset
        /// </summary>
        public int TailleOffset
        {
            get { return tailleOffset; }
        }
        /// <summary>
        /// Retourne la largeur de l'image
        /// </summary>
        public int Largeur
        {
            get { return largeur; }
        }
        /// <summary>
        /// Retourne la hauteur de l'image
        /// </summary>
        public int Hauteur
        {
            get { return hauteur; }
        }
        /// <summary>
        /// Retourne le nombre de bits par couleur
        /// </summary>
        public int NbBitForColor
        {
            get { return nbbitforcolor; }
        }
        /// <summary>
        /// Retourne la taille de l'image
        /// </summary>
        public int TailleImage
        {
            get { return tailleImage; }
        }
        /// <summary>
        /// Retourne la taille Originale
        /// </summary>
        public int TailleOriginale
        {
            get { return tailleOriginale; }
        }
        /// <summary>
        /// Retourne la matrice de pixel composant l'image. 
        /// </summary>
        public Pixel[,] Im
        {
            get { return im; }
            set { im = value; }
        }
    }
}
