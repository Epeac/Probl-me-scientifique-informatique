﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImageViewerPSI
{
    public class Pixel
    {
        byte r;
        byte g;
        byte b;
        /// <summary>
        /// Créer une instance Pixel. Prend les couleurs Rouges, Vertes et Bleu nécessaire pour un pixel.
        /// </summary>
        public Pixel(byte r, byte g, byte b)
        {
            this.r = r;
            this.g = g;
            this.b = b;
        }
        /// <summary>
        /// Retourne la couleur Rouge d'un Pixel
        /// </summary>
        public byte R
        {
            get { return this.r; }
            set { this.r = value; }
        }
        /// <summary>
        /// Retourne la couleur Verte d'un Pixel
        /// </summary>
        public byte G
        {
            get { return this.g; }
            set { this.g = value; }
        }
        /// <summary>
        /// Retourne la couleur Bleu d'un Pixel
        /// </summary>
        public byte B
        {
            get { return this.b; }
            set { this.b = value; }
        }

    }
}
